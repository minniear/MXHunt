# MXHunt

## Description
MXHunt is a tool that helps you find mail exchanger records related to a domain. It is useful for penetration testers and bug hunters who want to find out the mail exchanger records of a domain for reconnaissance purposes.
